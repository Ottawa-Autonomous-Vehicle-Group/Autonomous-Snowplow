
Install websocket-client:
  sudo pip install websocket-client


