
import tkinter as tk
from PIL import Image, ImageTk

window = tk.Tk()
window.geometry('480x480')
window.title("Rover Data Collection App")
#title=tk.Label(window,text="SnowPlow Obstacles Avoidance Data Collection", font=("Arial",15))
#title.grid(column=0, row=0)

lbl=tk.Label(window,text="Start..", font=("Arial Bold",25))
lbl.grid(column=0, row=1,ipadx=5, pady=5, sticky=tk.W+tk.N)
# lbl.pack()

def save_free():
	lbl.configure(text="Free")

def save_wait():
	lbl.configure(text="Wait")

def save_block():
	lbl.configure(text="Block")


free_btn= tk.Button(window, command=save_free, text="Free",bg="green",fg="white", font=("Arial",30))
free_btn.grid(column=0, row=2, padx=5, pady=5, sticky=tk.W+tk.E)
#free_btn.pack(side='right')

wait_btn= tk.Button(window, command=save_wait, text="Wait",bg="orange",fg="red", font=("Arial",30))
wait_btn.grid(column=0, row=3, padx=5, pady=5, sticky=tk.W+tk.E)
#wait_btn.pack(side='right')

block_btn= tk.Button(window, command=save_block, text="Block",bg="red",fg="white", font=("Arial",30))
block_btn.grid(column=0, row=4, padx=5, pady=5, sticky=tk.W+tk.E)
#block_btn.pack(side='right')

img = ImageTk.PhotoImage(Image.open("transmission.jpg"))
labelImage = tk.Label(window, image=img)
labelImage.grid(column=2,row=1,columnspan=8, rowspan=4, sticky=tk.W+tk.E+tk.N+tk.S, padx=5,pady=5)

#canvas=tk.Canvas(window,width=300,height=300)
#canvas.grid(column=4, row=3)
#canvas.pack()
#img = ImageTk.PhotoImage(Image.open("ball.png"))
#nvas.create_image(20,20,anchor=NW, image=img)

window.mainloop()
