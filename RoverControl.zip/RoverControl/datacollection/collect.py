# data collection inspired from Jetbot
# Converted to Python script

# This script to collect data for obstcale avoidance.
# It will identy items 
#      - Block: the rover turn around 
#      - Wait for obstcals 
#      - Free to continue.

import traitlets
import ipywidgets.widgets as widgets
from IPython.display import display
from jetbot import Camera, bgr8_to_jpeg

camera = Camera.instance(width=224, height=224)

image = widgets.Image(format='jpeg', width=224, height=224)  # this width and height doesn't necessarily have to match the camera

camera_link = traitlets.dlink((camera, 'value'), (image, 'value'), transform=bgr8_to_jpeg)

display(image)

# Create the 3 directories for datasets
import os
blocked_dir = 'dataset/blocked'
wait_dir = 'dataset/wait'
free_dir = 'dataset/free'

# we have this "try/except" statement because these next functions can throw an error if the directories exist already
try:
	os.makedirs(free_dir)
	os.makedirs(wait_dir)
	os.makedirs(blocked_dir)
except FileExistsError:
	print('Directories not created becasue they already exist')


button_layout = widgets.Layout(width='128px', height='64px')
free_button = widgets.Button(description='add free', button_style='success', layout=button_layout)
wait_button = widgets.Button(description='add wait', button_style='warning', layout=button_layout)
blocked_button = widgets.Button(description='add blocked', button_style='danger', layout=button_layout)
free_count = widgets.IntText(layout=button_layout, value=len(os.listdir(free_dir)))
wait_count = widgets.IntText(layout=button_layout, value=len(os.listdir(wait_dir)))
blocked_count = widgets.IntText(layout=button_layout, value=len(os.listdir(blocked_dir)))

display(widgets.HBox([free_count, free_button]))
display(widgets.HBox([wait_count, wait_button]))
display(widgets.HBox([blocked_count, blocked_button]))

from uuid import uuid1

def save_snapshot(directory):
	image_path = os.path.join(directory, str(uuid1()) + '.jpg')
	with open(image_path, 'wb') as f:
		f.write(image.value)

def save_free():
	global free_dir, free_count
	save_snapshot(free_dir)
	free_count.value = len(os.listdir(free_dir))

def save_wait():
	global wait_dir, wait_count
	save_snapshot(wait_dir)
	wait_count.value = len(os.listdir(wait_dir))
    
def save_blocked():
	global blocked_dir, blocked_count
	save_snapshot(blocked_dir)
	blocked_count.value = len(os.listdir(blocked_dir))

# attach the callbacks, we use a 'lambda' function to ignore the
# parameter that the on_click event would provide to our function
# because we don't need it.
free_button.on_click(lambda x: save_free())
wait_button.on_click(lambda x: save_wait())
blocked_button.on_click(lambda x: save_blocked())

display(image)
display(widgets.HBox([free_count, free_button]))
display(widgets.HBox([wait_count, wait_button]))
display(widgets.HBox([blocked_count, blocked_button]))

!zip -r -q dataset.zip dataset
