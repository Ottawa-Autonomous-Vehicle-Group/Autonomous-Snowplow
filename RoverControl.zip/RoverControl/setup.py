import glob
import subprocess
from setuptools import setup, find_packages, Extension

def build_libs():
    subprocess.call(['cmake','.'])
    subprocess.call(['make'])

build_libs

setup(
    name='snowplow',
    version='0.1',
    description='Autonomous SnowPlow',
    packages=find_packages()
)