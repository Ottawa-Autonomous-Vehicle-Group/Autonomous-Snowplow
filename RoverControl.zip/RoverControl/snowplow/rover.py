# Rover Motor Control
# 
# required:
# websocket-client installed 
#  $ pip install websocket-client
#  

import time
import logging
import websocket

ws = websocket.WebSocket()

class Rover():

    def __init__(self, *args, **kwargs):
        super(Rover, self).__init__(*args, **kwargs)
        # Connect to Wedsocket server

        print("Tying to connect ... ")
        try:
            ws.connect("ws://192.168.4.1:8325") # This is the default IP value of ESP32 - if different please update
            print ("Connected to WebSocket server")
        except ws.timeout  as err:
            logging.error("Connection TimeOut Exception: "+err)

    def forward(self,speed=100,duration=None):
        print("Forward "+speed)
        str = "M0," + speed
        ws.send(str)
        if duration:
            time.sleep(duration)
            ws.send("S0,0")
    
    def backward(self,speed=100,duration=None):
        print("Backward "+speed)
        str = "M0,-" + speed
        ws.send(str)
        if duration:
            time.sleep(duration)
            ws.send("S0,0")

    def right(self,angle=90):
        print("Turn Right "+angle)

    def left(self,angle=90):
        print("Turn Left "+angle)

    def stop(self):
        print("S T O P")
        ws.send("S0,0")

    def disconnect(self):
        print("Disconnet ")
        ws.close()

# Wait for server responce
#result = ws.recv()
#print("Received: "+result)

