# Rover Motor Control
# 
# required:
# websocket-vlient installed 
#  $ pip install websocket-client
#  

import time
import logging
import websocket

# Connect to Wedsocket server
ws = websocket.WebSocket()
print("Tying to connect ... ")
try:
    ws.connect("ws://192.168.4.1:8325") # This is the default value of ESP32 - if different please update
    print ("Connected to WebSocket server")
except ws.timeout  as err:
    logging.error("Connection TimeOut Exception: "+err)

# Wait for command 
str = input("Right motor command: ")
ws.send(str)
time.sleep(2)
ws.send("S0,0")

# Wait for server responce
#result = ws.recv()
#print("Received: "+result)

# Close connection
ws.close()