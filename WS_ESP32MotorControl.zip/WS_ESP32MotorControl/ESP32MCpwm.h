/**
 * ESP32MCpwn: Using ESP32 Motor Controller PWM (Pulse Weight Modulation)
 * 
 *  Copyright (C) 2019  Technology.cafe
 *  by Ayman Hindam
 */

#ifndef ESP32MCpwm_H
#define ESP32MCpwm_H


//#ifdef ESP32
#include "Arduino.h"

//#define PWD_freq 1000  // PWD frequency

class ESP32MCpwm
{
  public:
    void motorSetup(uint8_t pwmChannel, char port , uint32_t frequency, uint8_t gpio);
    void setDuty(uint8_t pwmChannel,char port, float duty );
    //For Stepper Motor
    void motorSetupStepper(uint8_t pwmChannel, uint32_t frequency, uint8_t gpioA, uint8_t gpioB);
    void setDutyStepper(uint8_t pwmChannel,float duty );

    void handle();
};
//#endif //ESP32 
#endif //ESP32MCpwm_H
