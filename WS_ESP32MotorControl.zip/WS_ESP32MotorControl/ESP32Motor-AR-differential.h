/*
 *   Motors Pin connection definitions
 */
 
#define LED_BUILTIN 22    // ESP32 built in LED Pin

//=== Define Motor and GPIO pin Connection ===
//-- Motor 0--Front Right--------------
const int MOTOR0PWM = 4;
const int MOTOR0F = 16;
const int MOTOR0R = 17;

//-- Motor 2--Front Left--
const int MOTOR2PWM = 25;
const int MOTOR2F = 26;
const int MOTOR2R = 27;


//-- Motor 1--Back Right--
const int MOTOR1PWM = 21;
const int MOTOR1F = 20;
const int MOTOR1R = 22;
//-- Motor 3--Back Left--
const int MOTOR3PWM = 19;
const int MOTOR3F = 23;
const int MOTOR3R = 18;


const int PWM_FREQUENCY = 10000;

int minInirtia = 20; // Minimum PMW value to move the motor in %
