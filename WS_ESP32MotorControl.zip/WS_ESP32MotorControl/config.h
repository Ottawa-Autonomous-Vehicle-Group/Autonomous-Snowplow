// Wifi info & websocket server port
const char *ssid = "SnowESP32";
const char *password = "oavg";
const int port = 8325;

//--- Set websocket through Router
bool SOFT_AP = false;
const char* ssid1   = "Hindam2";
const char* passwd1 = "password";
const char* ssid2   = "MakerPlaceNorth";
const char* passwd2 = "EnableMakers";
const char* ssid3   = "Hindam2-2.4Gplus";
const char* passwd3 = "password";
