/**
 * ESP32MCpwn: Using ESP32 Motor Controller PWM (Pulse Weight Modulation)
 * 
 *  We define 6 motor PWD channels (0 to 5) and each channel has 2 PWM signal output A/B (for H-Bridge forward and reverse). 
 *  Timers are connected to Operators (TIMER0 to OPERATOR0, ...). 
 *  However, for similar motors we use the same frequency so one timer in each unit could be enough!  
 *  Anyway, This setting can accomodate any 6 DC motors over H-Bridge. 
 *  Channels : 
 *      channel = 0 -> MCPWD Unit 0, Operator 0   as: MCPWM_UNIT_0, MCPWM0A / MCPWM0B
 *      channel = 1 -> MCPWD Unit 0, Operator 1   as: MCPWM_UNIT_0, MCPWM1A / MCPWM1B
 *      channel = 2 -> MCPWD Unit 0, Operator 2   as: MCPWM_UNIT_0, MCPWM2A / MCPWM2B
 *      channel = 3 -> MCPWD Unit 1, Operator 0   as: MCPWM_UNIT_0, MCPWM0A / MCPWM0B
 *      channel = 4 -> MCPWD Unit 1, Operator 1   as: MCPWM_UNIT_0, MCPWM1A / MCPWM1B
 *      channel = 5 -> MCPWD Unit 1, Operator 2   as: MCPWM_UNIT_0, MCPWM2A / MCPWM2B
 *      
 *  Tested with L298N and BTS7960     
 *      
 *  Copyright (C) 2019  Technology.cafe
 *  Developed by Ayman Hindam
 */

 
#include "ESP32MCpwm.h"

#include <stdio.h>

#include "esp_system.h"
#include "esp_attr.h"

#include "driver/mcpwm.h"
#include "soc/mcpwm_reg.h"
#include "soc/mcpwm_struct.h"

//#define debug(fmt, ...)
#define debug(fmt, ...) Serial.printf("%s: " fmt "\r\n", __func__, ##__VA_ARGS__)


/**
 *  Setup Motor and assign to pins 
 */
void ESP32MCpwm::motorSetup(uint8_t pwmChannel, char port , uint32_t frequency, uint8_t gpio)
{
  mcpwm_config_t pwmConfig;
  pwmConfig.frequency = frequency;    //Set frequency of MCPWM in Hz
  pwmConfig.cmpr_a = 0;
  pwmConfig.cmpr_b = 0;
  pwmConfig.duty_mode = MCPWM_DUTY_MODE_0;    //Active high duty  
  pwmConfig.counter_mode= MCPWM_UP_COUNTER ;  // = 1

  switch(pwmChannel)
  {
    case 0:
      debug("init MCPWM Motor 0");
      mcpwm_init(MCPWM_UNIT_0, MCPWM_TIMER_0, &pwmConfig);   // Setting Timer
      if(port == 'A') mcpwm_gpio_init(MCPWM_UNIT_0, MCPWM0A, gpio);          // Assign GPIO pin to operator 
      if(port == 'B') mcpwm_gpio_init(MCPWM_UNIT_0, MCPWM0B, gpio);          // Assign GPIO pin to operator
      break;

     case 1:
     debug("init MCPWM Motor 1");
      mcpwm_init(MCPWM_UNIT_0, MCPWM_TIMER_1, &pwmConfig);   // Setting Timer
      if(port == 'A')mcpwm_gpio_init(MCPWM_UNIT_0, MCPWM1A, gpio);          // Assign GPIO pin to operator 
      if(port == 'B')mcpwm_gpio_init(MCPWM_UNIT_0, MCPWM1B, gpio);          // Assign GPIO pin to operator
      break;
      
    case 2:
      debug("init MCPWM Motor 2");
      mcpwm_init(MCPWM_UNIT_0, MCPWM_TIMER_2, &pwmConfig);   // Setting Timer
      if(port == 'A') mcpwm_gpio_init(MCPWM_UNIT_0, MCPWM2A, gpio);          // Assign GPIO pin to operator 
      if(port == 'B') mcpwm_gpio_init(MCPWM_UNIT_0, MCPWM2B, gpio);          // Assign GPIO pin to operator
      break;
      
    case 3:
      debug("init MCPWM Motor 3");
      mcpwm_init(MCPWM_UNIT_1, MCPWM_TIMER_0, &pwmConfig);   // Setting Timer
      if(port == 'A') mcpwm_gpio_init(MCPWM_UNIT_1, MCPWM0A, gpio);          // Assign GPIO pin to operator 
      if(port == 'B') mcpwm_gpio_init(MCPWM_UNIT_1, MCPWM0B, gpio);          // Assign GPIO pin to operator
      break;
      
    case 4:
      debug("init MCPWM Motor 4");
      mcpwm_init(MCPWM_UNIT_1, MCPWM_TIMER_1, &pwmConfig);   // Setting Timer
      if(port == 'A') mcpwm_gpio_init(MCPWM_UNIT_1, MCPWM1A, gpio);          // Assign GPIO pin to operator 
      if(port == 'B') mcpwm_gpio_init(MCPWM_UNIT_1, MCPWM1B, gpio);          // Assign GPIO pin to operator
      break;
      
    case 5:
      debug("init MCPWM Motor 5");
      mcpwm_init(MCPWM_UNIT_1, MCPWM_TIMER_2, &pwmConfig);   // Setting Timer
      if(port == 'A') mcpwm_gpio_init(MCPWM_UNIT_1, MCPWM2A, gpio);          // Assign GPIO pin to operator 
      if(port == 'B') mcpwm_gpio_init(MCPWM_UNIT_1, MCPWM2B, gpio);          // Assign GPIO pin to operator
      break;   
  }
  
}

void ESP32MCpwm::setDuty(uint8_t pwmChannel,char port, float duty )
{
  if (duty < 0) duty = 0;
  if (duty>100) duty=100;  
  
  switch(pwmChannel)
  {
    case 0:
        debug("channel 0 %f", duty);
        if(port == 'A') mcpwm_set_duty(MCPWM_UNIT_0, MCPWM_TIMER_0, MCPWM_OPR_A,duty);
        if(port == 'B') mcpwm_set_duty(MCPWM_UNIT_0, MCPWM_TIMER_0, MCPWM_OPR_B,duty);
      break;

    case 1:
        debug("channel 1 %f", duty);
        if(port == 'A') mcpwm_set_duty(MCPWM_UNIT_0, MCPWM_TIMER_1, MCPWM_OPR_A,duty);
        if(port == 'B') mcpwm_set_duty(MCPWM_UNIT_0, MCPWM_TIMER_1, MCPWM_OPR_B,duty);
      break;

    case 2:
        debug("channel 2 %f", duty);
        if(port == 'A') mcpwm_set_duty(MCPWM_UNIT_0, MCPWM_TIMER_2, MCPWM_OPR_A,duty);
        if(port == 'B') mcpwm_set_duty(MCPWM_UNIT_0, MCPWM_TIMER_2, MCPWM_OPR_B,duty);
      break;

    case 3:
        debug("channel 3 %f", duty);
        if(port == 'A') mcpwm_set_duty(MCPWM_UNIT_1, MCPWM_TIMER_0, MCPWM_OPR_A,duty);
        if(port == 'B') mcpwm_set_duty(MCPWM_UNIT_1, MCPWM_TIMER_0, MCPWM_OPR_B,duty);
      break;

    case 4:
        debug("channel 4 %f", duty);
        if(port == 'A') mcpwm_set_duty(MCPWM_UNIT_1, MCPWM_TIMER_1, MCPWM_OPR_A,duty);
        if(port == 'B') mcpwm_set_duty(MCPWM_UNIT_1, MCPWM_TIMER_1, MCPWM_OPR_B,duty);
      break;

    case 5:
        debug("channel 5 %f", duty);
        if(port == 'A') mcpwm_set_duty(MCPWM_UNIT_1, MCPWM_TIMER_2, MCPWM_OPR_A,duty);
        if(port == 'B') mcpwm_set_duty(MCPWM_UNIT_1, MCPWM_TIMER_2, MCPWM_OPR_B,duty);
      break;
  }
}


void ESP32MCpwm::motorSetupStepper(uint8_t pwmChannel, uint32_t frequency, uint8_t gpioA, uint8_t gpioB){
  
}

void ESP32MCpwm::setDutyStepper(uint8_t pwmChannel,float duty )
{
  bool forward = true;   //for stepper
  if (duty < 0) {
    forward = false;
    duty = abs(duty);
  }
  if(duty>100) duty=100;  
  
  switch(pwmChannel)
  {
    case 0:
      if(forward){
        debug("channel 0 Forward");
        mcpwm_set_duty(MCPWM_UNIT_0, MCPWM_TIMER_0, MCPWM_OPR_A,duty);
        mcpwm_set_duty(MCPWM_UNIT_0, MCPWM_TIMER_0, MCPWM_OPR_B,0);
      }else {
        debug("channel 0 backward");
        mcpwm_set_duty(MCPWM_UNIT_0, MCPWM_TIMER_0, MCPWM_OPR_A,0);
        mcpwm_set_duty(MCPWM_UNIT_0, MCPWM_TIMER_0, MCPWM_OPR_B,duty);
      }
      break;

    case 1:
      if(forward){
        debug("channel 1 Forward");
        mcpwm_set_duty(MCPWM_UNIT_0, MCPWM_TIMER_1, MCPWM_OPR_A,duty);
        mcpwm_set_duty(MCPWM_UNIT_0, MCPWM_TIMER_1, MCPWM_OPR_B,0);
      }else {
        debug("channel 1 backward");
        mcpwm_set_duty(MCPWM_UNIT_0, MCPWM_TIMER_1, MCPWM_OPR_A,0);
        mcpwm_set_duty(MCPWM_UNIT_0, MCPWM_TIMER_1, MCPWM_OPR_B,duty);
      }
      break;
      
    case 2:
      if(forward){
        debug("channel 2 Forward");
        mcpwm_set_duty(MCPWM_UNIT_0, MCPWM_TIMER_2, MCPWM_OPR_A,duty);
        mcpwm_set_duty(MCPWM_UNIT_0, MCPWM_TIMER_2, MCPWM_OPR_B,0);
      }else {
        debug("channel 2 backward");
        mcpwm_set_duty(MCPWM_UNIT_0, MCPWM_TIMER_2, MCPWM_OPR_A,0);
        mcpwm_set_duty(MCPWM_UNIT_0, MCPWM_TIMER_2, MCPWM_OPR_B,duty);
      }
      break;
      
    case 3:
      if(forward){
        debug("channel 3 Forward");
        mcpwm_set_duty(MCPWM_UNIT_1, MCPWM_TIMER_0, MCPWM_OPR_A,duty);
        mcpwm_set_duty(MCPWM_UNIT_1, MCPWM_TIMER_0, MCPWM_OPR_B,0);
      }else {
        debug("channel 3 backward");
        mcpwm_set_duty(MCPWM_UNIT_1, MCPWM_TIMER_0, MCPWM_OPR_A,0);
        mcpwm_set_duty(MCPWM_UNIT_1, MCPWM_TIMER_0, MCPWM_OPR_B,duty);
      }
      break;
      
    case 4:
      if(forward){
        debug("channel 4 Forward");
        mcpwm_set_duty(MCPWM_UNIT_1, MCPWM_TIMER_1, MCPWM_OPR_A,duty);
        mcpwm_set_duty(MCPWM_UNIT_1, MCPWM_TIMER_1, MCPWM_OPR_B,0);
      }else {
        debug("channel 4 backward");
        mcpwm_set_duty(MCPWM_UNIT_1, MCPWM_TIMER_1, MCPWM_OPR_A,0);
        mcpwm_set_duty(MCPWM_UNIT_1, MCPWM_TIMER_1, MCPWM_OPR_B,duty);
      }
      break;
      
    case 5:
      if(forward){
        debug("channel 5 Forward");
        mcpwm_set_duty(MCPWM_UNIT_1, MCPWM_TIMER_2, MCPWM_OPR_A,duty);
        mcpwm_set_duty(MCPWM_UNIT_1, MCPWM_TIMER_2, MCPWM_OPR_B,0);
      }else {
        debug("channel 5 backward");
        mcpwm_set_duty(MCPWM_UNIT_1, MCPWM_TIMER_2, MCPWM_OPR_A,0);
        mcpwm_set_duty(MCPWM_UNIT_1, MCPWM_TIMER_2, MCPWM_OPR_B,duty);
      }
      break;
  }
  
}
